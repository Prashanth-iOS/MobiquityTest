//
//  DateExtension.swift
//  WeatherApp
//
//  Created by Prashanth samala on 23/02/21.
//  Copyright © 2021 Prashanth samala. All rights reserved.
//

import UIKit

extension Date {
    func dayOfWeek() -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE"
        return dateFormatter.string(from: self).capitalized
    }
}
