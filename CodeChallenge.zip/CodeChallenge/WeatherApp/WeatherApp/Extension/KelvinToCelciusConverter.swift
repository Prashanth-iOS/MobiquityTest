//
//  KelvinToCelciusConverter.swift
//  WeatherApp
//
//  Created by Prashanth samala on 23/02/21.
//  Copyright © 2021 Prashanth samala. All rights reserved.
//

import UIKit

extension Float {
    func truncate(places : Int)-> Float
    {
        return Float(floor(pow(10.0, Float(places)) * self)/pow(10.0, Float(places)))
    }
    
    func kelvinToCeliusConverter() -> Float {
        let constantVal : Float = 273.15
        let kelValue = self
        let celValue = kelValue - constantVal
        return celValue.truncate(places: 1)
    }
}
