//
//  SelfConfiguringCell.swift
//  WeatherApp
//
//  Created by Prashanth samala on 23/02/21.
//  Copyright © 2021 Prashanth samala. All rights reserved.
//

import UIKit

protocol SelfConfiguringCell {
    static var reuseIdentifier: String { get }
    func configure(with item: ForecastTemperature)
}
