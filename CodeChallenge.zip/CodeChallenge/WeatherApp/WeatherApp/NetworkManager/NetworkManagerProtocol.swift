//
//  NetworkManagerProtocol.swift
//  WeatherApp
//
//  Created by Prashanth samala on 23/02/21.
//  Copyright © 2021 Prashanth samala. All rights reserved.
//

import UIKit

protocol NetworkManagerProtocol {
    func fetchCurrentWeather(city: String, completion: @escaping (WeatherModel) -> ())
    func fetchCurrentLocationWeather(lat: String, lon: String, completion: @escaping (WeatherModel) -> ())
    func fetchNextFiveWeatherForecast(city: String, completion: @escaping ([ForecastTemperature]) -> ())
}
