//
//  NetworkProperties.swift
//  WeatherApp
//
//  Created by Prashanth samala on 23/02/21.
//  Copyright © 2021 Prashanth samala. All rights reserved.
//

import UIKit

struct NetworkProperties {
    static let API_KEY = "fae7190d7e6433ec3a45285ffcf55c86"
}
