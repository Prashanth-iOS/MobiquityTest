//
//  Forecast.swift
//  WeatherApp
//
//  Created by Prashanth samala on 23/02/21.
//  Copyright © 2021 Prashanth samala. All rights reserved.
//

import UIKit

struct WeatherInfo {
    let temp: Float
    let min_temp: Float
    let max_temp: Float
    let description: String
//  let icon: String
    let time: String
}

struct ForecastTemperature {
    let weekDay: String?
    let hourlyForecast: [WeatherInfo]?
}
